
<div>
    <div class="card">
        <div class="card-header">
            <input wire:model="search" type="text" class="form-control" placeholder="Ingrese Nombre del medicamento y/o Nombre de La farmacia">
        </div>
        <?php if($medicamentos->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead class="text-center">
                    <tr>
                        <th scope="col">Farmacia</th>
                        <th scope="col">Medicamento</th>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Cantidad</th>
                        <th scope="col">Valor</th>  
                    </tr>
                    </thead>
                    <tbody class="text-center">
                        <?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                            
                                <tr>
                                    <td><?php echo e($medicamento->name); ?></td>
                                    <td><?php echo e($medicamento->nombre_medicamento); ?></td>
                                    <td><?php echo e($medicamento->descripcion_medicamento); ?></td>
                                    <td><?php echo e($medicamento->cantidad); ?></td>
                                    <td><?php echo e($medicamento->valor); ?></td>
                                </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="card-body">
                <strong>No hay registros</strong>
            </div>
        <?php endif; ?>
        <div class="card-footer">
            <?php echo e($medicamentos->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\medicamento\resources\views/livewire/medicamento-index.blade.php ENDPATH**/ ?>