

<?php $__env->startSection('title', 'Agregar Usuario'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Agregar Usuario</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1 class="card-title">Ingrese los Campos Con los datos Requeridos</h1>
        </div>
        <div class="card-body">
            <?php echo Form::open(['route' => 'admin.conductors.store']); ?>


                <div class="form-group">
                    <?php echo form::label('tipo_licencia', 'Tipos de licencia'); ?>

                    <?php echo form::text('tipo_licencia', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el tipo de licencia']); ?>

                    <?php $__errorArgs = ['tipo_licenca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo form::label('annos_experiencia', 'Años de experiencia'); ?>

                    <?php echo form::number('annos_experiencia', null, ['class' => 'form-control', 'placeholder' => 'Ingrese los años de experiencia']); ?>


                    <?php $__errorArgs = ['annos_experiencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo form::label('nombre_conductor', 'Nombre del conductor'); ?>

                    <?php echo form::text('nombre_conductor', null, ['class' => 'form-control', 'placeholder' => 'Ingrese nombre del conductor']); ?>

                    
                    <?php $__errorArgs = ['nombre_conductor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo form::label('apellido_p_conductor', 'Apellido paterno del conductor'); ?>

                    <?php echo form::text('apellido_p_conductor', null, ['class' => 'form-control', 'placeholder' => 'Ingrese apellido paterno del conductor']); ?>


                    <?php $__errorArgs = ['apellido_p_conductor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo form::label('apellido_m_conductor', 'Apellido materno del conductor'); ?>

                    <?php echo form::text('apellido_m_conductor', null, ['class' => 'form-control', 'placeholder' => 'Ingrese apellido materno del conductor']); ?>

                    
                    <?php $__errorArgs = ['apellido_m_conductor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo form::label('telefono_conductor', 'Telefono del conductor'); ?>

                    <?php echo form::number('telefono_conductor', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el telefono del conductor']); ?>

                    <?php $__errorArgs = ['telefono_conductor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo form::label('direccion_conductor', 'Direccion del conductor'); ?>

                    <?php echo form::text('direccion_conductor', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la direccion del conductor']); ?>

                    <?php $__errorArgs = ['direccion_conductor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <?php echo form::label('automovil_id', 'Automovil'); ?>

                    <?php echo form::select('automovil_id', $automovil, null, ['class' => 'form-control', 'placeholder' => 'Seleccione Automovil ', 'readonly']); ?>


                    <?php $__errorArgs = ['automovil_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                

                <?php echo Form::submit('Agregar Conductor', ['class' => 'btn btn-primary']); ?>


            <?php echo Form::close(); ?>


            

        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e('/vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js'); ?>"></script>

    <script>
        $(document).ready( function() {
        $("#name").stringToSlug({
            setEvents: 'keyup keydown blur',
            getPut: '#contrasenna',
            space: '-'
  });
});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectapp\resources\views/admin/conductor/create.blade.php ENDPATH**/ ?>