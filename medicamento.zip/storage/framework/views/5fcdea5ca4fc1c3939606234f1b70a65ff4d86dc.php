

<?php $__env->startSection('title', 'Listado Usuarios Pendientes de Aprobacion'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.user.index')): ?>
        <a class="btn btn-secondary float-right" href="<?php echo e(route('admin.users.create')); ?>">Agregar Usuario</a>
    <?php endif; ?>
    <h1>Listado Usuarios Pendientes de Aprobacion</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users-index1')->html();
} elseif ($_instance->childHasBeenRendered('m2KxueI')) {
    $componentId = $_instance->getRenderedChildComponentId('m2KxueI');
    $componentTag = $_instance->getRenderedChildComponentTagName('m2KxueI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('m2KxueI');
} else {
    $response = \Livewire\Livewire::mount('admin.users-index1');
    $html = $response->html();
    $_instance->logRenderedChild('m2KxueI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicamento\resources\views/admin/user/index1.blade.php ENDPATH**/ ?>