<div>
    <div class="card">
            <div class="card-header">
                <input wire:model="search" type="text" class="form-control" placeholder="Ingrese Rut/Nombres/Apellidos/Correo de un Usuario">
            </div>
            <?php if($medicamentos->count()): ?>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead class="text-center">
                        <tr>
                            
                            <th scope="col">Nombre Medicamento</th>
                            <th scope="col">Descripcion Medicamento</th>
                            <th scope="col">Eliminado el:</th>
                            <th scope="col">Por el Usuario:</th>
                            
                        </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                        <tr>
                            <td><?php echo e($medicamento->nombre_medicamento); ?></td>
                            <td><?php echo e($medicamento->descripcion_medicamento); ?></td>
                            <td><?php echo e($medicamento->fecha_carga); ?></td>
                            <td><?php echo e($medicamento->name); ?></td>
                            
                            <td >
                                <form action="<?php echo e(route('admin.medicamentos.restaurar', $medicamento)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('put')); ?>

                                    <button type="submit" class="btn btn-success btn-sm" >Restaurar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <?php echo e($medicamentos->links()); ?>

                </div>
            <?php else: ?>
                <div class="card-body">
                    <strong>No hay registros</strong>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\medicamento\resources\views/livewire/admin/medicamentos-index3.blade.php ENDPATH**/ ?>