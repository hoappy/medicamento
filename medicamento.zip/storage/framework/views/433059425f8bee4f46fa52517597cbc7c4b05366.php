<div>
    <div class="card">
            <div class="card-header">
                <input wire:model="search" type="text" class="form-control" placeholder="Ingrese Rut/Nombres/Apellidos/Correo de un Usuario">
            </div>
            <?php if($medicamentos->count()): ?>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead class="text-center">
                        <tr>
                            
                            <th scope="col">Nombre Medicamento</th>
                            <th scope="col">Descripcion Medicamento</th>
                            <th scope="col">Cantidad:</th>
                            <th scope="col">Valor:</th>
                            <th scope="col">Asignado el:</th>
                        </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                        <tr>
                            <td><?php echo e($medicamento->nombre_medicamento); ?></td>
                            <td><?php echo e($medicamento->descripcion_medicamento); ?></td>
                            <td><?php echo e($medicamento->cantidad); ?></td>
                            <td><?php echo e($medicamento->valor); ?></td>
                            <td><?php echo e($medicamento->fecha_asigna); ?></td>
                            
                            <!--<td width="10px">
                                <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.medicamentos.edit', $medicamento)); ?>">Editar</a>
                            </td>-->
                           
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <?php echo e($medicamentos->links()); ?>

                </div>
            <?php else: ?>
                <div class="card-body">
                    <strong>No hay registros</strong>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\medicamento\resources\views/livewire/admin/medicamentos-index1.blade.php ENDPATH**/ ?>