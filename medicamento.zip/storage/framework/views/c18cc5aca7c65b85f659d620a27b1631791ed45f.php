

<?php $__env->startSection('title', 'Agregar Usuario'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Agregar Usuario</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1 class="card-title">Ingrese los Campos Con los datos Requeridos</h1>
        </div>
        <div class="card-body">
            <?php echo Form::open(['route' => 'admin.dependencias.store']); ?>


                <div class="form-group">
                    <?php echo form::label('nombre_dependencia', 'Nombre de dependencia'); ?>

                    <?php echo form::text('nombre_dependencia', null, ['class' => 'form-control', 'placeholder' => 'Ingrese nombre de la dependencia']); ?>

                </div>
                <div class="form-group">
                    <?php echo form::label('direccion_dependencia', 'Direccion de dependencia'); ?>

                    <?php echo form::text('direccion_dependencia', null, ['class' => 'form-control', 'placeholder' => 'Ingrese la direccion de la dependencia']); ?>

                </div>
                

                <?php echo Form::submit('Agregar Usuario', ['class' => 'btn btn-primary']); ?>


            <?php echo Form::close(); ?>


            

        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e('/vendor/jQuery-Plugin-stringToSlug-1.3/jquery.stringToSlug.min.js'); ?>"></script>

    <script>
        $(document).ready( function() {
        $("#name").stringToSlug({
            setEvents: 'keyup keydown blur',
            getPut: '#contrasenna',
            space: '-'
  });
});
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectapp\resources\views/admin/dependencia/create.blade.php ENDPATH**/ ?>