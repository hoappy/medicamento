

<?php $__env->startSection('title', 'Listado Cometidos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado Usuarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.cometidos.create')); ?>">Agregar Usuario</a>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead class="text-center">
                <tr>
                    <th scope="col">Nombres</th>
                    
                    
                    <!--<th scope="col">Detalles</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>-->
                    
                </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $cometidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cometido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                <tr>
                    <td><?php echo e($cometido->name); ?></td>
                    

                    <td width="10px"> 
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.cometidos.show', $cometido)); ?>">Detalles</a>
                    </td>
                    <td width="10px">
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.cometidos.edit', $cometido)); ?>">Editar</a>
                    </td>
                    <td width="10px">
                        <form href="<?php echo e(route('admin.cometidos.destroy', $cometido)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button tupe="submit" class="btn btn-danger btn-sm" >Eliminar</button>
                        </form>
                    </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectapp\resources\views/admin/cometido/index.blade.php ENDPATH**/ ?>