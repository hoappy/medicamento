<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Lista de Usuarios')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                

                <!-- tabla de usuarios -->
<div class="card-body container">
    <div class="card tex-center">
      <div class="card-header text-center">

      </div>
      
        <div class="table-responsive">
          <table class="table">
            <thead class="text-center">
              <tr>
                
               
                <th scope="col">Nombres</th>
                <th scope="col">Apellido Paterno</th>
                <th scope="col">Apellido Materno</th>
                <th scope="col">Email</th>
                <th scope="col">Direccion</th>
                <th scope="col">Grado</th>
                <th scope="col">Cargo</th>
                <th scope="col">Eliminar</th>
                <th scope="col">Editar</th>
                <th scope="col">Detalles</th>
                
              </tr>
            </thead>
            <tbody class="text-center">
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                
              <tr>
                <td><?php echo e($usuario->name); ?></td>
                <td><?php echo e($usuario->apellido_p); ?></td>
                <td><?php echo e($usuario->apellido_M); ?></td>
                <td><?php echo e($usuario->email); ?></td>
                <td><?php echo e($usuario->direccion); ?></td>
                <td><?php echo e($usuario->grado); ?></td>
                <td><?php echo e($usuario->nombre_cargo); ?></td>

                <a class="btn btn-danger" href="#" role="button">Eliminar</a>
                </td>
                <td>
                <a class="btn btn-success" href="#" role="button">Editar</a>
                </td>
                <td>
                <a class="btn btn-primary" href="#" role="button">Detalles</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              
            </tbody>
          </table>
        
      </div>

    </div>
    
    
    
  </div>
            


            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\projectapp\resources\views/userList.blade.php ENDPATH**/ ?>