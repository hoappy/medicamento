

<?php $__env->startSection('title', 'Listado de Conductor'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado de Conductor</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <strong><?php echo e(session('info')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.conductors.create')); ?>">Agregar Conductor</a>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead class="text-center">
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Apellido Paterno</th>
                    <th scope="col">Apellido Materno</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Tipo de Licencia</th>
                    <th scope="col">Años de experiencia</th>
                    
                    
                    <th scope="col">Detalles</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>
                    
                </tr>
                </thead>
                 <tbody class="text-center">
                    <?php $__currentLoopData = $conductors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conductor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                <tr>
                    <td><?php echo e($conductor->nombre_conductor); ?></td>
                    <td><?php echo e($conductor->apellido_p_conductor); ?></td>
                    <td><?php echo e($conductor->apellido_m_conductor); ?></td>
                    <td><?php echo e($conductor->telefono_conductor); ?></td>
                    <td><?php echo e($conductor->tipo_licencia); ?></td>
                    <td><?php echo e($conductor->annos_experiencia); ?></td>





                    

                    <td width="10px"> 
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.conductors.show', $conductor)); ?>">Detalles</a>
                    </td>
                    <td width="10px">
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.conductors.edit', $conductor)); ?>">Editar</a>
                    </td>
                    <td width="10px">
                        <form href="<?php echo e(route('admin.conductors.destroy', $conductor)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button tupe="submit" class="btn btn-danger btn-sm" >Eliminar</button>
                        </form>
                    </td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectapp\resources\views/admin/conductor/index.blade.php ENDPATH**/ ?>