

<?php $__env->startSection('title', 'Listado de Automoviles'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado de Automoviles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <strong><?php echo e(session('info')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <a class="btn btn-primary" href="<?php echo e(route('admin.automovils.create')); ?>">Agregar Automovil</a>
        </div>
        <div class="card-body">
            <div class="card-header">
                <h4>Automoviles Activos</h4>
            </div>    
            <table class="table table-striped">
                <thead class="text-center">
                <tr>
                    <th scope="col">Modelo Automovil</th>
                    <th scope="col">Marca Automovil</th>
                    <th scope="col">Anno</th>
                    <th scope="col">Tipo Automovil</th>
                    <th scope="col">Patente</th>
                    
                    <th scope="col">Detalles</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>
                    
                </tr>
                </thead>
                
                <tbody class="text-center">
                    <?php $__currentLoopData = $automovils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $automovil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <?php if($automovil->estado === '1'): ?>
                            <tr>
                                <td><?php echo e($automovil->modelo); ?></td>
                                <td><?php echo e($automovil->marca_automovil); ?></td>
                                <td><?php echo e($automovil->anno); ?></td>
                                <td><?php echo e($automovil->tipo_automovil); ?></td>
                                <td><?php echo e($automovil->patente); ?></td>

                                <td width="10px"> 
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.automovils.show', $automovil)); ?>">Detalles</a>
                                </td>
                                <td width="10px">
                                    <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.automovils.edit', $automovil)); ?>">Editar</a>
                                </td>
                                <td width="10px">
                                    <!--<form href="<?php echo e(route('admin.automovils.destroy', $automovil)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        @method_field('delete')
                                        <button type="submit" class="btn btn-danger btn-sm" >Eliminar</button>
                                    </form>-->
                                    
                                    <form action="<?php echo e(route('admin.automovils.desactivar', $automovil)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('put')); ?>

                                        <button type="submit" class="btn btn-danger btn-sm" >Desactivar</button>
                                    </form>
                                    
                                </td>
                            </tr>
                        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                </tbody>
            </table>
        </div>
        <div class="card-body">
            <div class="card-header">
                <h4>Automviles Inactivos</h4>
            </div> 
            <table class="table table-striped">
                <thead class="text-center">
                <tr>
                    <th scope="col">Modelo Automovil</th>
                    <th scope="col">Marca Automovil</th>
                    <th scope="col">Anno</th>
                    <th scope="col">Tipo Automovil</th>
                    <th scope="col">Patente</th>
                    
                    <!--<th scope="col">Detalles</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>-->
                    
                </tr>
                </thead>
                
                <tbody class="text-center">
                    <?php $__currentLoopData = $automovils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $automovil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <?php if($automovil->estado === '0'): ?>
                            <tr>
                                <td><?php echo e($automovil->modelo); ?></td>
                                <td><?php echo e($automovil->marca_automovil); ?></td>
                                <td><?php echo e($automovil->anno); ?></td>
                                <td><?php echo e($automovil->tipo_automovil); ?></td>
                                <td><?php echo e($automovil->patente); ?></td>

                                <td width="10px"> 
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.automovils.show', $automovil)); ?>">Detalles</a>
                                </td>
                                <td width="10px">
                                    <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.automovils.edit', $automovil)); ?>">Editar</a>
                                </td>
                                <td width="10px">
                                    <!--<form href="<?php echo e(route('admin.automovils.destroy', $automovil)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        @method_field('delete')
                                        <button type="submit" class="btn btn-danger btn-sm" >Eliminar</button>
                                    </form>-->
                                    
                                        <form action="<?php echo e(route('admin.automovils.activar', $automovil)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('put')); ?>

                                            <button type="submit" class="btn btn-success btn-sm" >Activar</button>
                                        </form>
                                    
                                </td>
                            </tr>
                        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectapp\resources\views/admin/automovil/index.blade.php ENDPATH**/ ?>