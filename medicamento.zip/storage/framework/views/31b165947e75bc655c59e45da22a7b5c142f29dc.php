

<?php $__env->startSection('title', 'Listado de Dependencias'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado de Dependencias</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.dependencias.create')); ?>">Agregar Dependencia</a>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead class="text-center">
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Direccion</th>
                                        
                    <th scope="col">Detalles</th>
                    <th scope="col">Editar</th>
                    
                    
                </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $dependencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dependencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                <tr>
                    <td><?php echo e($dependencia->nombre_dependencia); ?></td>
                    <td><?php echo e($dependencia->direccion_dependencia); ?></td>
                    
                    <td width="10px"> 
                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.dependencias.show', $dependencia)); ?>">Detalles</a>
                    </td>
                    <td width="10px">
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.dependencias.edit', $dependencia)); ?>">Editar</a>
                    </td>
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                </tbody>
            </table>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectapp\resources\views/admin/dependencia/index.blade.php ENDPATH**/ ?>