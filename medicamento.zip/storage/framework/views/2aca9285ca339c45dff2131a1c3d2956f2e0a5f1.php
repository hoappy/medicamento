

<?php $__env->startSection('title', 'Listado Usuarios Aceptados'); ?>

<?php $__env->startSection('content_header'); ?>
        
    <h1>Listado Medicamentos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.medicamentos-index1')->html();
} elseif ($_instance->childHasBeenRendered('9rpZjRS')) {
    $componentId = $_instance->getRenderedChildComponentId('9rpZjRS');
    $componentTag = $_instance->getRenderedChildComponentTagName('9rpZjRS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9rpZjRS');
} else {
    $response = \Livewire\Livewire::mount('admin.medicamentos-index1');
    $html = $response->html();
    $_instance->logRenderedChild('9rpZjRS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicamento\resources\views/admin/medicamento/index1.blade.php ENDPATH**/ ?>