<div>
    <div class="card">
            <div class="card-header">
                <input wire:model="search" type="text" class="form-control" placeholder="Ingrese Rut/Nombres/Apellidos/Correo de un Usuario">
            </div>
            <?php if($users->count()): ?>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead class="text-center">
                        <tr>
                            
                            <th scope="col">Nombres</th>
                            
                            <th scope="col">Email</th>
                            <th scope="col">Direccion</th>
                            <th scope="col">Telefono</th>
                            <th scope="col">Coordenadas</th>

                            <th scope="col">Fecha Solicitud</th>
                            <th scope="col">Fecha Activacion</th>
                            
                            <!--<th scope="col">Detalles</th>
                            <th scope="col">Editar</th>
                            <th scope="col">Eliminar</th>-->
                            
                        </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->direccion); ?></td>
                            <td><?php echo e($user->telefono); ?></td>
                            <td><?php echo e($user->coordenadas); ?></td>
                            <td><?php echo e($user->fecha_ingreso); ?></td>
                            <td><?php echo e($user->fecha_activacion); ?></td>
                           

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.user.index')): ?>
                            <?php endif; ?>    
                            <!--<td>
                                <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.users.roleasig', $user)); ?>">Asignar Rol</a>
                            </td>-->
                        
                            <td width="10px">
                                <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.users.edit', $user)); ?>">Editar</a>
                            </td>
                        
                            <!-- <td width="10px">
                                <form href="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('delete')); ?>

                                    <button tupe="submit" class="btn btn-danger btn-sm" >Eliminar</button>
                                </form>
                            </td> -->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <?php echo e($users->links()); ?>

                </div>
            <?php else: ?>
                <div class="card-body">
                    <strong>No hay registros</strong>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\medicamento\resources\views/livewire/admin/users-index.blade.php ENDPATH**/ ?>