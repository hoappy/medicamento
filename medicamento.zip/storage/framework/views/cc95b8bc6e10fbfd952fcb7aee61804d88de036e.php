

<?php $__env->startSection('title', 'Agregar Medicamento'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Agregar Medicamento</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1 class="card-title">Ingrese los Campos Con los datos Requeridos</h1>
        </div>
        <div class="card-body">
            <?php echo Form::open(['route' => 'admin.medicamentos.store']); ?>


                <div class="form-group">
                    <?php echo form::label('nombre_medicamento', 'Nombre Medicamento'); ?>

                    <?php echo form::text('nombre_medicamento', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el/los Nombre/s del Usuario']); ?>


                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-group">
                    <?php echo form::label('descripcion_medicamento', 'Descripcion Medicamento'); ?>

                    <?php echo form::text('descripcion_medicamento', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el apellido paterno del Usuario a Agregar']); ?>


                    <?php $__errorArgs = ['descripcion_medicamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <?php echo Form::submit('Agregar Medicamento', ['class' => 'btn btn-primary']); ?>


            <?php echo Form::close(); ?>


        </div>
    </div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicamento\resources\views/admin/medicamento/create.blade.php ENDPATH**/ ?>