

<?php $__env->startSection('title', 'Listado Usuarios Aceptados'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.user.index')): ?>
        <a class="btn btn-secondary float-right" href="<?php echo e(route('admin.users.create')); ?>">Agregar Usuario</a>
    <?php endif; ?>
    <h1>Listado Usuarios Aprobados</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users-index')->html();
} elseif ($_instance->childHasBeenRendered('OGMrbNj')) {
    $componentId = $_instance->getRenderedChildComponentId('OGMrbNj');
    $componentTag = $_instance->getRenderedChildComponentTagName('OGMrbNj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OGMrbNj');
} else {
    $response = \Livewire\Livewire::mount('admin.users-index');
    $html = $response->html();
    $_instance->logRenderedChild('OGMrbNj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medicamento\resources\views/admin/user/index.blade.php ENDPATH**/ ?>