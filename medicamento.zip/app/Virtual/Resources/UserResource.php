/ **
 * @OA \ Schema (
 * title = "ProjectResource",
 * description = "Recurso del proyecto",
 * @OA \ Xml (
 * nombre = "ProjectResource"
 *)
 *)
 * / class ProjectResource { / **
 

    
     * @OA \ Propiedad (
     * title = "Datos",
     * descripción = "Contenedor de datos"
     *)
     *
     * @var \ App \ Virtual \ Models \ Project []
     * / datos $ privados ; }
    