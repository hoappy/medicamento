<?php return array (
  'admin.medicamentos-index' => 'App\\Http\\Livewire\\Admin\\MedicamentosIndex',
  'admin.medicamentos-index1' => 'App\\Http\\Livewire\\Admin\\MedicamentosIndex1',
  'admin.medicamentos-index2' => 'App\\Http\\Livewire\\Admin\\MedicamentosIndex2',
  'admin.medicamentos-index3' => 'App\\Http\\Livewire\\Admin\\MedicamentosIndex3',
  'admin.users-index' => 'App\\Http\\Livewire\\Admin\\UsersIndex',
  'admin.users-index1' => 'App\\Http\\Livewire\\Admin\\UsersIndex1',
  'admin.users-index2' => 'App\\Http\\Livewire\\Admin\\UsersIndex2',
  'medicamento-index' => 'App\\Http\\Livewire\\MedicamentoIndex',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);